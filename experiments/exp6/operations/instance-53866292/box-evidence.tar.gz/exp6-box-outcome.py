"""Operator supervisor: real preflight, then the committed endpoint campaign."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import traceback

ROOT = Path('/workspace/emergence-paper')
OUT = Path('/workspace/exp6_operator')
PYTHON = '/workspace/venv/bin/python'
HEAD = 'e2ae59c98f7ce02330c5d90d6992a6701a8cda01'
SEAL = '5dbe5f2f700b2d64b28cfb6f29c6334eb7c12978b7bbba6051c7e0f7d9508189'
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

def write(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2)+'\n')
    tmp.replace(path)

def preflight():
    from experiments.exp6 import battery_6 as b6, pins_6 as p6, records_6 as r6
    from experiments.exp6.run import _common_6 as cm, endpoint_6 as ep
    assert git('rev-parse', 'HEAD') == HEAD
    assert not git('status', '--porcelain')
    assert cm.gates()['n_bound'] == 33
    seal = ep.require_predictor_seal(b6.EXP6)
    assert seal['sha256'] == SEAL
    assert not (b6.EXP6/'results/endpoint').exists()
    assert not (b6.EXP6/'results/sweep').exists()
    meta = {'started_utc': now(), 'head': HEAD, 'pid': os.getpid(),
            'predictor_seal_sha256': SEAL,
            'predictor_seal_file_sha256': r6.sha256_file(r6.seal_path(b6.EXP6))}
    write(OUT/'preflight-meta.json', meta)
    print('[operator] outcome preflight invocation', json.dumps(meta), flush=True)
    from experiments.exp6.run import preflight_6 as pf
    result = pf.run_outcome(device='cuda')  # production defaults, no injections
    write(OUT/'preflight-summary.json', result)
    p6.require_prereg_6()
    ep.require_predictor_seal(b6.EXP6)
    p6.check_frozen_6()
    p6.check_imports_6(exempt=p6.EXEMPT_6)
    meta.update(ended_utc=now(), passed=bool(result['pass']))
    write(OUT/'preflight-meta.json', meta)
    print('[operator] preflight', 'PASS' if result['pass'] else 'FAIL', flush=True)
    return 0 if result['pass'] else 1

def run():
    path = OUT/'outcome-status.json'
    assert not path.exists(), 'Run already recorded; inspect before restarting'
    state = {'pid': os.getpid(), 'sid': os.getsid(0), 'started_utc': now(),
             'head': HEAD, 'predictor_seal_sha256': SEAL, 'stage': 'starting',
             'operator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    env = {**os.environ, 'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1',
           'HF_HUB_DISABLE_PROGRESS_BARS': '1'}
    env.pop('HF_HUB_DISABLE_XET', None)
    current = None
    code = 1
    def save(**update):
        state.update(update)
        write(path, state)
    def terminate(signum, frame):
        raise SystemExit(128+signum)
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    save()
    try:
        setup = json.loads((OUT/'setup-status.json').read_text())
        assert setup['exit_code'] == 0 and setup['stage'] == 'ready-for-preflight'
        for stage, args, logpath in (
            ('preflight', [PYTHON, '-u', str(Path(__file__).resolve()), '--preflight'], OUT/'preflight.log'),
            ('endpoints', ['bash', str(ROOT/'experiments/exp6/run/campaign_endpoint_6.sh')], Path('/workspace/campaign_6.log'))):
            save(stage=stage, stage_started_utc=now())
            with logpath.open('ab') as log:
                current = subprocess.Popen(args, env=env, stdin=subprocess.DEVNULL,
                                           stdout=log, stderr=subprocess.STDOUT,
                                           start_new_session=True)
                save(child_pid=current.pid)
                rc = current.wait()
                current = None
            save(**{stage+'_exit_code': rc, stage+'_ended_utc': now()})
            if rc:
                raise RuntimeError(f'{stage} exited {rc}; see {logpath}')
        code = 0
        save(stage='complete')
    except BaseException as exc:
        save(stage='error', error=f'{type(exc).__name__}: {exc}')
        traceback.print_exc()
        if isinstance(exc, SystemExit) and isinstance(exc.code, int):
            code = exc.code
    finally:
        if current is not None and current.poll() is None:
            os.killpg(current.pid, signal.SIGTERM)
            try:
                current.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(current.pid, signal.SIGKILL)
                current.wait()
        save(ended_utc=now(), exit_code=code, child_pid=None)
        print(json.dumps(state, indent=2), flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(preflight() if '--preflight' in sys.argv else run())
