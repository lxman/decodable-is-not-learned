"""Box-only operator: pinned setup and transport/dry-run checks, no LLM load."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import time

OUT = Path('/workspace/exp6_operator')
OUT.mkdir(exist_ok=True)
state = {'pid': os.getpid(), 'sid': os.getsid(0), 'stage': 'setup',
         'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1',
       'HF_HUB_DISABLE_PROGRESS_BARS': '1'}
env.pop('HF_HUB_DISABLE_XET', None)
def save(**update):
    state.update(update)
    (OUT/'setup-status.json').write_text(json.dumps(state, indent=2)+'\n')
save()
try:
    subprocess.run(['bash', '/workspace/box_setup_6.sh'], env=env, check=True)
    python = '/workspace/venv/bin/python'
    repo = '/workspace/emergence-paper'
    check = '''import json,torch
from experiments.exp6.run import _common_6 as cm
assert torch.cuda.is_available(), 'Pinned torch cannot initialize CUDA'
h=cm.host_record('cuda'); assert not cm.host_failures(h)
print('host',json.dumps(h,sort_keys=True))
print('prereg bindings',cm.gates()['n_bound'])
'''
    subprocess.run([python, '-c', check], cwd=repo, env=env, check=True)
    subprocess.run([python, '-m', 'experiments.exp6.run.endpoint_6', '--device', 'cuda', '--dry-run'],
                   cwd=repo, env=env, check=True)
    save(stage='transport-probe')
    # The frozen transport probe downloads the same pinned Pythia-160m weight
    # file twice in scratch caches. It never constructs a model or reads an item.
    transport = '''import json
from pathlib import Path
from experiments.exp5.collect_5 import measure_transports_5
r=measure_transports_5(cache_root=Path('/workspace/transport_probe_6'))
Path('/workspace/exp6_operator/transports.json').write_text(json.dumps(r,indent=2)+'\\n')
print('transports',json.dumps(r,sort_keys=True))
assert r['xet_mbps'] is not None and r['used']=='xet'
'''
    subprocess.run([python, '-c', transport], cwd=repo, env=env, check=True)
    save(stage='ready-for-preflight', exit_code=0)
except BaseException as exc:
    save(stage='error', error=f'{type(exc).__name__}: {exc}', exit_code=1)
    raise
finally:
    save(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
