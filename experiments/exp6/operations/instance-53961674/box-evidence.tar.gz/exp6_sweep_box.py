#!/usr/bin/env python3
"""One detached invocation of Exp 6's frozen sweep campaign on the rental."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import traceback

ROOT = Path('/workspace/emergence-paper')
OUT = Path('/workspace/exp6_operator')


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def run(head):
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    path = OUT / 'sweep-status.json'
    assert not path.exists(), 'Sweep already invoked; inspect rather than rerun'
    state = {'pid': os.getpid(), 'sid': os.getsid(0), 'head': head,
             'started_utc': now(), 'stage': 'checking',
             'operator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

    def save(**updates):
        state.update(updates)
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(state, indent=2) + '\n')
        tmp.replace(path)

    def terminate(signum, frame):
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    current = None
    code = 1
    save()
    try:
        setup = json.loads((OUT / 'setup-status.json').read_text())
        assert setup['exit_code'] == 0 and setup['stage'] == 'ready-for-sweep'
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == head
        assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
        assert not (ROOT / 'experiments/exp6/results/sweep').exists()
        subprocess.run(['git', 'merge-base', '--is-ancestor', '98d207404', 'HEAD'], check=True)
        from experiments.exp6 import battery_6 as b6
        from experiments.exp6.run import _common_6 as cm, endpoint_6 as ep, sweep_6 as sw
        assert cm.gates()['n_bound'] == 33
        predictor = ep.require_predictor_seal(b6.EXP6)['sha256']
        endpoint = sw.require_endpoint_seal(b6.EXP6)
        assert predictor == '5dbe5f2f700b2d64b28cfb6f29c6334eb7c12978b7bbba6051c7e0f7d9508189'
        assert endpoint == 'cd662c0249161278efd61967c4ad4adb824c73e2853cc16e3ede68f76d6e0e22'
        env = {**os.environ, 'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1',
               'HF_HUB_DISABLE_PROGRESS_BARS': '1'}
        env.pop('HF_HUB_DISABLE_XET', None)
        save(stage='sweeping', predictor_sha256=predictor, endpoint_sha256=endpoint)
        with Path('/workspace/campaign_6.log').open('ab') as log:
            current = subprocess.Popen(
                ['bash', str(ROOT / 'experiments/exp6/run/campaign_sweep_6.sh')],
                env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True)
            save(child_pid=current.pid, child_pgid=current.pid)
            while True:
                try:
                    rc = current.wait(timeout=30)
                    break
                except subprocess.TimeoutExpired:
                    save(heartbeat_utc=now())
        if rc:
            raise RuntimeError(f'Frozen sweep campaign exited {rc}; see campaign_6.log')
        code = 0
        save(stage='complete')
    except BaseException as exc:
        save(stage='error', error=f'{type(exc).__name__}: {exc}')
        traceback.print_exc()
    finally:
        if current is not None and current.poll() is None:
            os.killpg(current.pid, signal.SIGTERM)
            try:
                current.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(current.pid, signal.SIGKILL)
                current.wait()
        save(exit_code=code, child_pid=None, ended_utc=now())
    return code


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head', required=True)
    raise SystemExit(run(parser.parse_args().head))
