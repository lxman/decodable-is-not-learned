"""Pinned setup and transport probe for the sweep; no model construction."""
import datetime
import json
import os
from pathlib import Path
import subprocess

OUT=Path('/workspace/exp6_operator');OUT.mkdir(exist_ok=True)
state={'pid':os.getpid(),'sid':os.getsid(0),'stage':'setup'}
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1','HF_HUB_DISABLE_PROGRESS_BARS':'1'}
env.pop('HF_HUB_DISABLE_XET',None)
def save(**updates):
    state.update(updates);tmp=OUT/'setup-status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(OUT/'setup-status.json')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not (OUT/'setup-status.json').exists()
save(started_utc=now())
try:
    subprocess.run(['bash','/workspace/box_setup_6.sh'],env=env,check=True)
    python='/workspace/venv/bin/python';repo='/workspace/emergence-paper'
    check='''import json,torch
from experiments.exp6.run import _common_6 as cm, sweep_6 as sw
from experiments.exp6 import battery_6 as b6,families_6 as fm
assert torch.cuda.is_available()
h=cm.host_record('cuda');assert not cm.host_failures(h)
print('host',json.dumps(h,sort_keys=True));print('prereg bindings',cm.gates()['n_bound'])
print('endpoint seal',sw.require_endpoint_seal(b6.EXP6))
for family in fm.FAMILIES_6:print('dry-run',family,sw.run(family,dry_run=True))
'''
    subprocess.run([python,'-c',check],cwd=repo,env=env,check=True)
    save(stage='transport-probe')
    transport='''import json
from pathlib import Path
from experiments.exp5.collect_5 import measure_transports_5
r=measure_transports_5(cache_root=Path('/workspace/transport_probe_6'))
Path('/workspace/exp6_operator/transports.json').write_text(json.dumps(r,indent=2)+'\\n')
print('transports',json.dumps(r,sort_keys=True));assert r['xet_mbps'] is not None and r['used']=='xet'
'''
    subprocess.run([python,'-c',transport],cwd=repo,env=env,check=True)
    save(stage='ready-for-sweep',exit_code=0)
except BaseException as exc:
    save(stage='error',error=f'{type(exc).__name__}: {exc}',exit_code=1);raise
finally:save(ended_utc=now())
